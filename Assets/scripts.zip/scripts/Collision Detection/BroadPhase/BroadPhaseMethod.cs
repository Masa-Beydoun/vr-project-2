﻿public enum BroadPhaseMethod
{
    SweepAndPrune,
    UniformGrid,
    Octree
}
